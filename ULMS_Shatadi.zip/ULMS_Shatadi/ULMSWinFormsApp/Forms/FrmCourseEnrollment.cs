﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmCourseEnrollment : Form
    {
        private List<Enrollment> enrollments = new List<Enrollment>();

        // Method to check if student is already enrolled
        private bool IsStudentEnrolled(string studentId, string courseName)
        {
            // Check if the student is already enrolled in the same course
            return enrollments.Any(e => e.StudentId == studentId && e.CourseName == courseName);
        }
        public FrmCourseEnrollment()
        {
            InitializeComponent();
        }

        private void btnEnroll_Click(object sender, EventArgs e)
        {
            // Intentional weak business-rule validation for testing purposes
            Enrollment enrollment = new Enrollment
            {
                StudentId = txtEnrollStudentId.Text,
                StudentName = txtEnrollStudentName.Text,
                CourseName = cmbCourse.Text,
                Semester = cmbSemester.Text
            };
            if (IsStudentEnrolled(enrollment.StudentId , enrollment.CourseName)){
                MessageBox.Show("Student is already enrolled in this course!");
                return;
            }
            else
            {
                txtEnrollmentOutput.Text =
                "Enrollment completed successfully!" + Environment.NewLine +
                "Student ID: " + enrollment.StudentId + Environment.NewLine +
                "Student Name: " + enrollment.StudentName + Environment.NewLine +
                "Course: " + enrollment.CourseName + Environment.NewLine +
                "Semester: " + enrollment.Semester;

            }

            //txtEnrollmentOutput.Text =
            //    "Enrollment completed successfully!" + Environment.NewLine +
            //    "Student ID: " + enrollment.StudentId + Environment.NewLine +
            //    "Student Name: " + enrollment.StudentName + Environment.NewLine +
            //    "Course: " + enrollment.CourseName + Environment.NewLine +
            //    "Semester: " + enrollment.Semester;

        }

        private void btnClearEnrollment_Click(object sender, EventArgs e)
        {
            txtEnrollStudentId.Clear();
            txtEnrollStudentName.Clear();
            cmbCourse.SelectedIndex = -1;
            cmbSemester.SelectedIndex = -1;
            txtEnrollmentOutput.Clear();
            txtEnrollStudentId.Focus();
        }

        private void btnBackEnrollment_Click(object sender, EventArgs e)
        {
            this.Close();
        }



    }
}
